-- AlterTable
ALTER TABLE "Resume" ADD COLUMN     "resumeName" TEXT NOT NULL DEFAULT '';
