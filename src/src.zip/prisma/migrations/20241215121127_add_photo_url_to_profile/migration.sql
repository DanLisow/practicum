-- AlterTable
ALTER TABLE "Profile" ADD COLUMN     "photoUrl" TEXT;
